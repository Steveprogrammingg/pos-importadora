from flask import Blueprint

auth_bp = Blueprint("auth", __name__)
context_bp = Blueprint("context", __name__)
main_bp = Blueprint("main", __name__)
